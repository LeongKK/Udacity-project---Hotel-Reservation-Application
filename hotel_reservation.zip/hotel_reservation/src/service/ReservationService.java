package service;

import model.*;

import java.util.*;

public class ReservationService {
    private static model.Reservation reservation;
    private static model.Room room;
    private static IRoom;

    Map<String, Customer> mapOfCustomer = new HashMap<String, Customer>();
    ArrayList<Customer> customer = new ArrayList<Customer>();

    public void addRoom(IRoom room) {

    }

    public IRoom getARoom(String roomId) {

    }

    public Reservation reserveARoom(Customer customer, IRoom room, Date checkInDate, Date checkOutDate) {

    }

    public Collection<IRoom> findRooms(Date checkInDate, Date checkOutDate){

    }

    public Collection<Reservation> getCustomersReservation(Customer customer) {

    }

    public void printAllReservation(){

    }

}
