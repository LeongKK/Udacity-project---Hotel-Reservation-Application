package service;

import model.Customer;

import java.util.*;

public class CustomerService {
    private static model.Customer Customer;
    Map<String, Customer> mapOfCustomer = new HashMap<String, Customer>();
    ArrayList<Customer> customer = new ArrayList<Customer>();

    public void addCustomer(String email, String firstName, String lastName) {
       Scanner scanner = new Scanner(System.in);
       try {
           System.out.println("Enter your first name: ");
           firstName = scanner.nextLine();
           System.out.println("Enter your last name: ");
           lastName = scanner.nextLine();
           System.out.println("Enter your email: ");
           email = scanner.nextLine();
       } catch (Exception ex) {
           ex.getLocalizedMessage();
       } finally {
           scanner.close();
       }
       Customer customer = new Customer(firstName, lastName, email);
       mapOfCustomer.put(customer.getEmail(), customer);
    }

    public Customer getCustomer(String customerEmail) {
        return mapOfCustomer.get(customerEmail);
    }

    public Collection<Customer> getAllCustomer() {
        for (String email : mapOfCustomer.keySet()) {
            System.out.println(email);
        }
    }
}
