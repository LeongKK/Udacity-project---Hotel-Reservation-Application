package model;

public class Tester {
    public static void main(String[] args) {
        Customer customer = new Customer("Kah", "Leong", "email");
        System.out.println(customer);
    }
}